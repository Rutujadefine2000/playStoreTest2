//
//  MyCollectionView.swift
//  PlayStoreApp1
//
//  Created by Brahmastra on 02/01/23.
//  Copyright © 2023 Brahmastra. All rights reserved.
//

import UIKit

class MyCollectionView: UICollectionViewCell {
    
    @IBOutlet weak var myImg: UIImageView!
    @IBOutlet weak var myLabel: UILabel!
}
