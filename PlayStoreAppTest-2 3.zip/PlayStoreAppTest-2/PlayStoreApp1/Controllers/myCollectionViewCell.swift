//
//  nyCollectionViewCell.swift
//  PlayStoreApp1
//
//  Created by Brahmastra on 20/01/23.
//  Copyright © 2023 Brahmastra. All rights reserved.
//

import UIKit

//class myCollectionViewCell: UICollectionViewCell {
//    @IBOutlet weak var myLabel: UILabel!
//    
//}
