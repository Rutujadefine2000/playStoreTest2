//
//  MovieViewController.swift
//  PlayStoreApp1
//
//  Created by Brahmastra on 03/01/23.
//  Copyright © 2023 Brahmastra. All rights reserved.
//

import UIKit
import SideMenu

class MovieData{
    var Movietype : String?
    var Moviename : [String]?
    
    init(Movietype: String, Moviename: [String]){
        self.Movietype = Movietype
        self.Moviename = Moviename
    }
}
class MovieViewController: UIViewController ,UITextFieldDelegate{
 var movieDataList : Welcome?
 var movieData = [MovieData]()
@IBOutlet weak var SelectedCollectionView: UICollectionView!
let itemname:[String]=["For you","Top charts","Children","Events","Premium","Categories"]
@IBOutlet weak var searchtextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        movieData.append(MovieData.init(Movietype: "Discover recommended Movie", Moviename: ["Action Movies"]))
        movieData.append(MovieData.init(Movietype: "Suggested for You", Moviename: ["Monster Movies"]))
        movieData.append(MovieData.init(Movietype: "Suggested for You", Moviename: ["Adventure Movies"]))
        jsonPasring()
        searchtextField.delegate = self
       
}
     
    private func setupSideMenu() {
        SideMenuManager.default.leftMenuNavigationController = storyboard?.instantiateViewController(withIdentifier: "LeftMenuNavigationController") as? SideMenuNavigationController
        self.navigationController?.isNavigationBarHidden = false
        SideMenuManager.default.addScreenEdgePanGesturesToPresent(toView: view)
    }
    func makeSettings() -> SideMenuSettings{
        var settings = SideMenuSettings()
        settings.allowPushOfSameClassTwice = false
        settings.presentationStyle = .menuSlideIn
        settings.statusBarEndAlpha = 0
        let screenBounds = UIScreen.main.bounds
        let width = screenBounds.width
        let height = screenBounds.height
        
        settings.menuWidth = width/1.4
        return settings}
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let sideMenuNavigationController = segue.destination as? SideMenuNavigationController else { return }
        sideMenuNavigationController.settings = makeSettings()
        
    }
   
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
       
        return searchtextField.resignFirstResponder()
    }
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
func jsonPasring(){
           let url = URL(string: "https://api.themoviedb.org/3/movie/popular?api_key=60af9fe8e3245c53ad9c4c0af82d56d6&language=en-US&page=1")
           URLSession.shared.dataTask(with: url!) { (data, response, error)
               in
               guard let data = data else { return }
               do{
                   self.movieDataList = try? JSONDecoder().decode(Welcome.self, from: data)
                  
               }catch{
                   print(error.localizedDescription)
               }
    }.resume()
       }
    func selected() {
        
    }
}


extension MovieViewController: UITableViewDelegate, UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        return self.movieData.count
    }
 func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        1
}
func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! MovieCell
        if let data = self.movieDataList {
            cell.getDataFromVC(model: self.movieDataList!.results)
        }
        else
            {
                
            }
            return cell
        }
        func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
            
            return movieData[section].Movietype
            
        }
    }

extension MovieViewController: UICollectionViewDelegate, UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        self.itemname.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = SelectedCollectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! SelectedCollectionViewCell
        cell.label1.text = self.itemname[indexPath.row]
      //  cell.label1.textColor = UIColor.blue
        cell.label1.textColor = UIColor.black
        cell.layer.cornerRadius = 20.0
       // cell.label1.layer.cornerRadius = 10.0
        //        let backgroundLabel = UILabel()
        //        backgroundLabel.textColor = UIColor.blue
               let backgroundView = UIView()
        backgroundView.backgroundColor = UIColor.lightGray
                cell.selectedBackgroundView = backgroundView
       /// self.SelectedCollectionView.textcolor = UIColor.blue
                
      //  cell.label1.layer.cornerRadius = 10.0
        //cell?.imageView1.layer.cornerRadius = 10.0
        //  cell.selectedBackgroundView = backgroundLabel
        return cell
    }
    
}
