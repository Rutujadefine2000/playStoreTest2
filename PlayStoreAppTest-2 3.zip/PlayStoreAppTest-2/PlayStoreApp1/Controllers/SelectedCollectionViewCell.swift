//
//  SelectedCollectionViewCell.swift
//  PlayStoreApp1
//
//  Created by Brahmastra on 25/01/23.
//  Copyright © 2023 Brahmastra. All rights reserved.
//

import UIKit

class SelectedCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var label1: UILabel!
}
